package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class AddNewActivity extends AppCompatActivity {

    private EditText editTextNazivObroka;
    private static TextView textViewVreme;
    private static TextView textViewDatum;
    private  Button buttonDatum;
    private  Button buttonVreme;
    private Button buttonDodati;
    private Button buttonOdustati;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new);
        //pribavljam reference u on create a dobro je da budu deklarsane u aktiviti klasi jer cu ih koristitti i na drugim mestima
        editTextNazivObroka = findViewById(R.id.editTextTextNazivObroka);
        textViewDatum = (TextView)findViewById(R.id.textViewOdabranDatum);
        textViewVreme = (TextView) findViewById(R.id.textViewOdabranoVreme);
        buttonDatum = (Button) findViewById(R.id.buttonDatum);
        buttonVreme = (Button) findViewById(R.id.buttonVreme);
        buttonDodati = (Button)findViewById(R.id.buttonDodati);
        buttonOdustati = (Button)findViewById(R.id.buttonOdustati);

        buttonDatum.setOnClickListener(new View.OnClickListener() {
            //bilo bi lep[e da ovo bude odvojena klasa
            @Override
            public void onClick(View v) {
                DialogFragment newFragment = new DatePickerFragment();
                newFragment.show(getSupportFragmentManager(), "datePicker");
            }
        });

        buttonDodati.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //String text = editTextNazivObroka.getEditableText().toString() + "," + textViewDatum.getText() + "," + textViewVreme.getText();
                //Toast.makeText(AddNewActivity.this, text, Toast.LENGTH_SHORT).show();
                Intent data = new Intent();
                data.putExtra("naziv",editTextNazivObroka.getEditableText().toString() );
                data.putExtra("datum", textViewDatum.getText());
                data.putExtra("vreme", textViewVreme.getText());
                setResult(Activity.RESULT_OK, data);
                finish();
            }
        });

        buttonOdustati.setOnClickListener(new View.OnClickListener() {
            //bilo bi lep[e da ovo bude odvojena klasa
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.podesavanja:
                return true;
            case R.id.brisanje:
                //toDoAdapter.clear();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    //koristim drugi nacin ya pravljenje lisenera van on create metode
    //onda moram u xml dodati rucno ili u diyajnu isto moze
    public void showTimePickerDialog(View v) {
        DialogFragment newFragment = new TimePickerFragment();
        newFragment.show(getSupportFragmentManager(), "timePicker");
    }

    public static class DatePickerFragment extends DialogFragment
            implements DatePickerDialog.OnDateSetListener {

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the current date as the default date in the picker
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            // Create a new instance of DatePickerDialog and return it
            return new DatePickerDialog(getActivity(), this, year, month, day);
        }



        public void onDateSet(DatePicker
                                      view, int year, int month, int day) {
            // Do something with the date chosen by the user
            //ove datume treba nekako da isformatiram npr sa simple date format ovo ovde je lose!!
            textViewDatum.setText (day + "."+ month + "." + year+ ".");
        }
    }

    public static class TimePickerFragment extends DialogFragment
            implements TimePickerDialog.OnTimeSetListener {

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the current time as the default values for the picker
            final Calendar c = Calendar.getInstance();
            int hour = c.get(Calendar.HOUR_OF_DAY);
            int minute = c.get(Calendar.MINUTE);

            // Create a new instance of TimePickerDialog and return it
            return new TimePickerDialog(getActivity(), this, hour, minute,
                    DateFormat.is24HourFormat(getActivity()));
        }

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            // Do something with the time chosen by the user
            textViewVreme.setText(hourOfDay + ":" + minute);
            //vo treba lepse
        }
    }
}
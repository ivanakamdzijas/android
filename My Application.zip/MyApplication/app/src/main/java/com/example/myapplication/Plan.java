package com.example.myapplication;

public class Plan {
    String naziv;
    String datum;
    String vreme;

public Plan(){

}

public String getNaziv(){
    return this.naziv;
}

public String getVreme(){
    return this.vreme;
}

public String getDatum(){
    return this.datum;
}

public void setNaziv(String naziv){
    this.naziv = naziv;
}

public void setDatum(String datum){
    this.datum = datum;
}

public void setVreme(String vreme){
    this.vreme = vreme;
}
}

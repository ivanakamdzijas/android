package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ListPlan extends AppCompatActivity {

    private RecyclerView recyclerView;
    private Button buttonDodatiNovi;
    private static final int ADD_ITEM_REQUEST_CODE = 1;
    private ToDoAdapter toDoAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        //ovo se koristi da se poboljsaju performanse kada ynamo da ce recycler biti fiksne velicine
        //u nasem slucaju nije fiksen evelicine nego non stop dodajemo
        //recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        List<Plan> planovi = new ArrayList<>();
        toDoAdapter = new ToDoAdapter(planovi);
        recyclerView.setAdapter(toDoAdapter);
        buttonDodatiNovi = findViewById(R.id.buttonDodatiNovi);
        buttonDodatiNovi.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent( ListPlan.this, AddNewActivity.class);
                startActivityForResult(intent, ADD_ITEM_REQUEST_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == Activity.RESULT_OK && requestCode == ADD_ITEM_REQUEST_CODE){
            Plan plan = new Plan();
            plan.setNaziv(data.getStringExtra("naziv"));
            plan.setDatum(data.getStringExtra("datum"));
            plan.setVreme(data.getStringExtra("vreme"));
            toDoAdapter.add(plan);
        }
    }
}



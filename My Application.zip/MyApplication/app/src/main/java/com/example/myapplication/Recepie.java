package com.example.myapplication;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Recepie {



    @SerializedName("ingr")
    @Expose
    private Integer ingr;

    public Integer getTitle() {
        return this.ingr;
    }

    public void setTitle(Integer ingr) {
        this.ingr = ingr;
    }


}

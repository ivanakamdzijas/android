package com.example.myapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RecipeActivity extends AppCompatActivity {

    TextView textViewTitle;
    EditText editTextSearch;

    ImageButton buttonSearch;
    Retrofit retrofit;
    RecepiesInterface recepiesInterface;
    String url ="https://api.edamam.com/";
    static final int PERMISSIONS_REQUEST_INTERNET = 1;
    static final String apikey = "a674ae7f68675fbf1f0c590239a55073";
    static final String apiid = "3c265af6";
    public final String TAG= "RecipeActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);
        //pokusavam
        textViewTitle = findViewById(R.id.textViewTitle);
        editTextSearch = findViewById(R.id.editTextSearch);
        buttonSearch = findViewById(R.id.imageButtonSearch);

        buttonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String searchtext = editTextSearch.getText().toString();

                if (!searchtext.equals("")) {

                    createRequest(searchtext);
                }
            }
        });
        checkPermissions();
        retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        recepiesInterface = retrofit.create(RecepiesInterface.class);
    }
        private void createRequest(String searchText) {
            Call<HitsClass> call =recepiesInterface.getRecepies(searchText, apiid, apikey);
            Log.i(TAG,call.request().url().toString());
            //Toast.makeText(RecipeActivity.this, call.request().url().toString(), Toast.LENGTH_LONG).show();
            call.enqueue(new Callback<HitsClass>() {

                @Override
                public void onResponse(Call<HitsClass> call, Response<HitsClass> response) {
                    Toast.makeText(RecipeActivity.this, "OK ?", Toast.LENGTH_SHORT).show();
                    if (response.code() == 200) {
                        //radi sadaa!!! :)
                        Toast.makeText(RecipeActivity.this, "OK 200", Toast.LENGTH_SHORT).show();
                        Log.i(TAG, response.body().toString());
                        HitsClass recipesResponse = response.body();
                        List<HitsClass.Hit> hits = recipesResponse.getHits();

                        updateUI(hits.get(0));

                    }

                }



                @Override
                public void onFailure(Call<HitsClass> call, Throwable t) {

                    Toast.makeText(RecipeActivity.this, "Something went wrong...Please try later!", Toast.LENGTH_SHORT).show();
                }
            });
        }




        private void updateUI(HitsClass.Hit hit) {
            textViewTitle.setText("Title: " + hit.getRecipe().getLabel());
        }


        private void checkPermissions() {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.INTERNET},
                        PERMISSIONS_REQUEST_INTERNET);
            }
        }

        @Override
        public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
            switch (requestCode) {
                case PERMISSIONS_REQUEST_INTERNET: {
                    if (grantResults.length > 0
                            && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Permission not granted", Toast.LENGTH_SHORT).show();
                    }
                    return;
                }
            }
        }



    }



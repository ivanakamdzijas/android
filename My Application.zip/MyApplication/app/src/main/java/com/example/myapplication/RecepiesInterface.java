package com.example.myapplication;


import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;


public interface RecepiesInterface {


    @GET("/search")
    Call<HitsClass> getRecepies(@Query("q") String q, @Query("app_id") String app_id, @Query("app_key") String app_key);
}

package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ToDoAdapter extends RecyclerView.Adapter<ToDoAdapter.ToDoViewHolder> {
    List<Plan> listaPlanova;

    public ToDoAdapter(List<Plan> listaPlanova){
        this.listaPlanova = listaPlanova;
    }


    @NonNull
    @Override
    public ToDoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Create a new view, which defines the UI of the list item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        ToDoViewHolder vh = new ToDoViewHolder(view);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull ToDoAdapter.ToDoViewHolder holder, int position) {
        // Get element from your dataset at this position and replace the
        // contents of the view with that element
        holder.textViewPlan.setText(listaPlanova.get(position).getNaziv());
        holder.datum.setText(listaPlanova.get(position).getDatum());
        holder.vreme.setText(listaPlanova.get(position).getVreme());

    }

    @Override
    public int getItemCount() {
        return listaPlanova.size();
    }

    public void add(Plan plan){
        listaPlanova.add(plan);
        notifyDataSetChanged();
    }

    //view holder je jedna stavka u listi u stvari
    public static class ToDoViewHolder extends RecyclerView.ViewHolder {
        private TextView textViewPlan;
        private TextView datum;
        private TextView vreme;

        public ToDoViewHolder(View view) {
            super(view);
            // Define click listener for the ViewHolder's View

            textViewPlan = (TextView) view.findViewById(R.id.textViewPlan);
            datum = (TextView) view.findViewById(R.id.datum);
            vreme = (TextView) view.findViewById(R.id.vreme);
        }
    }
}
